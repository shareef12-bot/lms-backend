package com.lms.auth.model;

public enum Role {
    STUDENT,
    TRAINER,
    ADMIN,
    BUSINESS
}
