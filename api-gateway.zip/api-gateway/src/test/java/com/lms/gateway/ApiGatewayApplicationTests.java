package com.lms.gateway;

// Completely disable Spring Boot tests for gateway
public class ApiGatewayApplicationTests {

}
